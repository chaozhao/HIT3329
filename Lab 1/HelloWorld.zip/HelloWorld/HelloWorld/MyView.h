//
//  MyView.h
//  HelloWorld
//
//  Created by Chao Zhao on 3/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyView : UIView

@end
